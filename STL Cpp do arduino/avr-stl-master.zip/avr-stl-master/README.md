# The C++ Standard Template Library for the Arduino

This is the source code that accompanies my [blog article](http://andybrown.me.uk/2011/01/15/the-standard-template-library-stl-for-avr-with-c-streams/) regarding porting the SGI C++ STL to the Arduino. Please read the article for full details.
